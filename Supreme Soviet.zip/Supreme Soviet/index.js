const { Client } = require('discord.js');

const client = new Client({
    intents: 20025343
});

const TOKEN = 'MTMyNDMwNDI1NzgzODc0MzU4Mw.GDG581.1ET5h3yWqC1TkasIDTsh-LXdMNqHJ4s67zXO6o';
const ROLE_ID = '1324049677905035295';
const REQUIRED_ROLE_ID = '1324037634842034227';

client.once('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
});

client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    const args = message.content.split(" ");
    const command = args[0];
    const hasRequiredRole = message.member.roles.cache.has(REQUIRED_ROLE_ID);
    if (command === '?rape') {
        if (message.author.id === '269853766369411073') return message.channel.send('Shut up Ukraine supporter.');
        else if (!hasRequiredRole) return message.reply('You are not communist enough to use this command.');
        const user = message.mentions.members.first();
        if (!user) return message.reply('Please select a user to rape.');
        const role = message.guild.roles.cache.get(ROLE_ID);
        if (!role) return message.reply('does not exist.');
        try {
            await user.roles.add(role);
            if (user.id === '269853766369411073') message.channel.send(`Successfully Raped Ukraine Supporter!!!`);
            else message.channel.send(`Successfully Raped <@${user.id}>!!!`); 
        } catch (error) {
            console.error(error);
            message.reply('There was an error');
        }
    } else if (command === '?unrape') {
        if (message.author.id === '269853766369411073') return message.channel.send('Shut up Ukraine supporter.');
        else if (!hasRequiredRole) return message.reply('You are not communist enough to use this command.');
        const user = message.mentions.members.first();
        if (!user) return message.reply('Please select a user to unrape.');
        const role = message.guild.roles.cache.get(ROLE_ID);
        if (!role) return message.reply('does not exist.');
        try {
            await user.roles.remove(role);
            if (user.id === '269853766369411073') message.channel.send(`He doesnt deserve it.`);
            else message.channel.send(`<@${user.id}> You wake up with a strange headache and You do not remember anything that happened in the past day.`);
        } catch (error) {
            console.error(error);
            message.reply('There was an error');
        }
    }
});

client.login(TOKEN);