const express = require('express');
const axios = require('axios');
const { spawn } = require('child_process');

const app = express();
const PORT = 3002;

app.get('/', async (req, res) => {
    const imageUrl = req.query.url;
    const ext = req.query.type;

    if (!imageUrl) return res.status(400).send('Image URL is required. Pass it as a query parameter: ?url=<image_url>');
    if (!ext) return res.status(400).send('Image Type is required. Pass it as a query parameter: ?type=<image_url>');

    try {
        const response = await axios.get(imageUrl, {
            responseType: 'arraybuffer',
        });

        const webpImageBuffer = Buffer.from(response.data);

        const convert = spawn('convert', [`${ext}:-`, 'png:-']);

        convert.stdin.write(webpImageBuffer);
        convert.stdin.end();

        res.setHeader('Content-Type', 'image/png');

        convert.stdout.pipe(res);

        convert.stderr.on('data', (err) => {
            console.error(`ImageMagick error: ${err.toString()}`);
        });

        convert.on('error', (err) => {
            console.error(`Failed to start ImageMagick: ${err.message}`);
            res.status(500).send('Error processing image.');
        });
    } catch (err) {
        console.error(`Error fetching or processing image: ${err.message}`);
        res.status(500).send('Error fetching or processing image.');
    }
});

app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
