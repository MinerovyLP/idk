import { WebSocketServer } from 'ws';
import { createRequire } from "module";
const require = createRequire(import.meta.url);
const axios = require('axios');

const Port = 3001;
const wss = new WebSocketServer({ port: Port });
console.log(`Running on Port: ${Port}`);

wss.on('connection', function message(ws) {
  ws.data = {};
  ws.data.lastPing = Date.now();
  ws.on('message', function message(data) {
    ws.data.lastPing = Date.now();
    if (data.toString().includes("?list")) {
      let arr = [];
      for (const client of wss.clients) {
        arr.push(client.data.name);
      }
      ws.send(arr.join("\n"));
    }
    else if (data.toString().startsWith("?name")) {
      ws.data.name = data.toString().split(" ").pop();
    }
    else {
      for (const client of wss.clients) {
        client.send(data.toString());
      }
    }
  });
});

setInterval(() => {
	for (const client of wss.clients) {
		if (client.data.lastPing + 180000 < Date.now()) client.close();
	}
}, 180000);